<?php

return [
    'create' => 'Crear', 
    'update' => 'Actualizar',
    'delete' => 'Eliminar',
    'create_trainer' => 'Crear un entrenador &plus;'
];