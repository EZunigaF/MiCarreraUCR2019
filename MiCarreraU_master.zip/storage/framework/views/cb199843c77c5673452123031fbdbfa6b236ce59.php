<?php $__env->startSection('content'); ?>

<div class="container">
    <?php $__env->startComponent('components.crun_form', [
    'test' => null,
    'action' => route('tests.store')
    ]); ?>
    <?php $__env->slot('method'); ?>
        <?php echo method_field('POST'); ?>
    <?php $__env->endSlot(); ?>

    <?php $__env->slot('button_text'); ?>
    <?php echo app('translator')->getFromJson('Añadir'); ?>
    <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Zuniga\Desktop\Unversidad2019\MCRUN\CRUN\resources\views/cruns/create.blade.php ENDPATH**/ ?>