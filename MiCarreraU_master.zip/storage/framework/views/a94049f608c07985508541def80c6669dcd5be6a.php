<?php $__env->startSection('content'); ?>

    <?php $__env->startComponent('components.crun_form', [
        'test' => $test,
        'action' => route('tests.update',$test->id),
    ]); ?>
        <?php $__env->slot('method'); ?>
            <?php echo method_field('PUT'); ?>
        <?php $__env->endSlot(); ?>

        <?php $__env->slot('button_text'); ?>
            <?php echo app('translator')->getFromJson('Actualizar'); ?>
        <?php $__env->endSlot(); ?>
    <?php echo $__env->renderComponent(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Zuniga\Desktop\Unversidad2019\MCRUN\CRUN\resources\views/cruns/edit.blade.php ENDPATH**/ ?>