<?php $__env->startSection('content'); ?>


<?php if(auth()->guard()->check()): ?>
    <a href="<?php echo e(route('tests.create')); ?>" class="crun_create_btn btn btn-primary danger px-md-5">Añadir Carrera Universitaria CRUN</a>
<?php endif; ?>


<table class="table table-striped">
        <thead 
                  style="text-align: center;">
            <tr>
              <td><h4><strong>Carrera Universitaria</strong></h4></td>
              <td><h4><strong>Sede Universitaria</strong></h4></td>
              <td><h4><strong>Corte Anual</strong></h4></td>
              <td><h4><strong>Etiqueta</strong></h4></td>
              <td><h6 style="padding-top: 0.5vw;"><strong>Editar Información</strong></h6></td>
              <td><h6 style="padding-top: 0.5vw;"><strong>Acciones disponibles:</strong></h6></td>
              
            </tr>
        </thead>
        <tbody
                style="text-align: center;">
            <?php $__currentLoopData = $tests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $test): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><a href="<?php echo e(route('listGuest',$test->id)); ?>" class="btn btn-success"><h5><?php echo e($test->crun_name); ?></h5></a></td></td>
                <td><h5><?php echo e($test->crun_sede); ?></h5></td>
                <td><h5><?php echo e($test->crun_corte); ?></h5></td>
                <td><h5><?php echo e($test->crun_etiqueta); ?></h5></td>
                <td><a href="<?php echo e(route('tests.edit',$test->id)); ?>" class="btn btn-primary">Editar</a></td>
                <td>
                    <form action="<?php echo e(route('tests.destroy', $test->id)); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger" type="submit">Eliminar</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Zuniga\Desktop\Unversidad2019\MCRUN\CRUN\resources\views/cruns/index.blade.php ENDPATH**/ ?>