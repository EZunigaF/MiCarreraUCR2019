<?php

namespace CRUN;

use Illuminate\Database\Eloquent\Model;

class CRUN extends Model
{
    //
}
